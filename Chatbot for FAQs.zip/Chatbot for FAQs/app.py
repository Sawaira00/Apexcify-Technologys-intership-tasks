import nltk
from nltk.stem import WordNetLemmatizer
from nltk.corpus import stopwords
import json
import os
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from groq import Groq

# Initialize Flask app
app = Flask(__name__)
CORS(app)

# --- GROQ CONFIGURATION ---
GROQ_API_KEY = "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"
client = Groq(api_key=GROQ_API_KEY)

# Download necessary NLTK data
def download_nltk_data():
    print("Downloading NLTK data...")
    try:
        nltk.download('punkt', quiet=True)
        nltk.download('wordnet', quiet=True)
        nltk.download('stopwords', quiet=True)
        nltk.download('punkt_tab', quiet=True)
        print("NLTK data downloaded successfully.")
    except Exception as e:
        print(f"Error downloading NLTK data: {e}")

download_nltk_data()

# Initialize NLP tools
lemmatizer = WordNetLemmatizer()
stop_words = set(stopwords.words('english'))

def preprocess(text):
    tokens = nltk.word_tokenize(text.lower())
    tokens = [lemmatizer.lemmatize(token) for token in tokens if token.isalnum() and token not in stop_words]
    return " ".join(tokens)

# Load FAQ data
def load_faq():
    with open('faq_data.json', 'r') as f:
        return json.load(f)

faqs = load_faq()
faq_questions = [faq['question'] for faq in faqs]
faq_answers = [faq['answer'] for faq in faqs]
preprocessed_faqs = [preprocess(q) for q in faq_questions]

# Vectorizer with n-grams for context retrieval
vectorizer = TfidfVectorizer(ngram_range=(1, 3))
tfidf_matrix = vectorizer.fit_transform(preprocessed_faqs)

def get_groq_response(user_query):
    try:
        completion = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[
                {
                    "role": "user",
                    "content": user_query
                }
            ],
            temperature=0.7,
            max_tokens=1024,
        )
        return completion.choices[0].message.content
    except Exception as e:
        print(f"Groq API Error: {e}")
        return None

@app.route('/')
def index():
    return send_from_directory('.', 'index.html')

@app.route('/<path:path>')
def static_files(path):
    return send_from_directory('.', path)

@app.route('/chat', methods=['POST'])
def chat():
    data = request.json
    user_query = data.get('message', '')
    
    if not user_query:
        return jsonify({"answer": "Please provide a question."})

    # 1. Local FAQ Matching (Priority)
    processed_query = preprocess(user_query)
    query_vec = vectorizer.transform([processed_query])
    similarities = cosine_similarity(query_vec, tfidf_matrix).flatten()
    top_indices = similarities.argsort()[::-1]
    
    best_match_index = top_indices[0]
    max_similarity = similarities[best_match_index]
    
    # If we have a very strong match in FAQ, use it immediately
    if max_similarity > 0.6:
        print(f"Strong local match found ({max_similarity:.2f}). Using FAQ.")
        return jsonify({"answer": faq_answers[best_match_index], "source": "Local FAQ"})

    # 2. AI Response via Groq
    print(f"Query: {user_query} | Fetching Direct Groq response...")
    ai_response = get_groq_response(user_query)
    
    if ai_response:
        return jsonify({"answer": ai_response, "source": "Groq AI"})

    # 3. Fallback to best local match if Groq fails
    if max_similarity > 0.15:
        response = faq_answers[best_match_index]
    else:
        response = "I'm sorry, I'm having trouble connecting to my brain. Please try again later or contact support@aiassistantpro.com."

    return jsonify({"answer": response, "source": "Local FAQ"})

if __name__ == '__main__':
    print("Starting Flask server on http://127.0.0.1:5000")
    app.run(debug=True, port=5000)
