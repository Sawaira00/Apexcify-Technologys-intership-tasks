const chatMessages = document.getElementById('chatMessages');
const chatForm = document.getElementById('chatForm');
const userInput = document.getElementById('userInput');
const typingIndicator = document.getElementById('typingIndicator');

function addMessage(text, isUser = false) {
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message');
    messageDiv.classList.add(isUser ? 'user-message' : 'bot-message');
    messageDiv.textContent = text;
    chatMessages.appendChild(messageDiv);
    
    // Scroll to bottom
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function toggleTyping(show) {
    typingIndicator.style.display = show ? 'flex' : 'none';
    if (show) {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
}

async function handleChat(e) {
    e.preventDefault();
    const message = userInput.value.trim();
    
    if (!message) return;

    // Clear input
    userInput.value = '';
    
    // Add user message
    addMessage(message, true);
    
    // Show typing indicator
    toggleTyping(true);

    try {
        const response = await fetch('http://127.0.0.1:5000/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ message }),
        });

        const data = await response.json();
        
        // Hide typing indicator after a small delay to feel natural
        setTimeout(() => {
            toggleTyping(false);
            addMessage(data.answer);
        }, 800);

    } catch (error) {
        console.error('Error:', error);
        toggleTyping(false);
        addMessage("Sorry, I'm having trouble connecting to the server. Please make sure the backend is running.");
    }
}

chatForm.addEventListener('submit', handleChat);

// Focus input on load
window.onload = () => userInput.focus();
