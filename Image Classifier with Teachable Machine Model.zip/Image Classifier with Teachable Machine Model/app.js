// --- DATABASE (LocalStorage Simulation) ---
const DB_USERS = 'emoai_users';
const DB_LOGS = 'emoai_logs';

if (!localStorage.getItem(DB_USERS)) localStorage.setItem(DB_USERS, JSON.stringify({}));
if (!localStorage.getItem(DB_LOGS)) localStorage.setItem(DB_LOGS, JSON.stringify({}));

// --- STATE VARIABLES ---
let currentUser = null;
let model, maxPredictions;
let isModelLoaded = false;

// USER'S CUSTOM MODEL URL
const MY_TEACHABLE_MACHINE_URL = "https://teachablemachine.withgoogle.com/models/0TEJHtnDj/"; 

// --- VIEWS ---
const viewHome = document.getElementById('view-home');
const viewAuth = document.getElementById('view-auth');
const viewDashboard = document.getElementById('view-dashboard');

// --- DOM ELEMENTS ---
const headerActionLink = document.getElementById('header-action-link');
const headerGetStarted = document.getElementById('header-get-started');
const logoLink = document.getElementById('logo-link');

const btnGetStarted = document.getElementById('btn-get-started');
const authForm = document.getElementById('auth-form');
const emailInput = document.getElementById('email');
const nameInput = document.getElementById('name');
const nameGroup = document.getElementById('name-group');
const tabLogin = document.getElementById('tab-login');
const tabSignup = document.getElementById('tab-signup');
const authTitle = document.getElementById('auth-title');
const authSubmitBtn = document.getElementById('auth-submit-btn');
const authError = document.getElementById('auth-error');

// Dashboard Elements
const uploadArea = document.getElementById('upload-area');
const imageUploadInput = document.getElementById('image-upload');
const uploadContent = document.getElementById('upload-content');
const previewContainer = document.getElementById('preview-container');
const imagePreview = document.getElementById('image-preview');
const clearImageBtn = document.getElementById('clear-image-btn');

const primaryClassText = document.getElementById('primary-class');
const confirmedBadge = document.getElementById('confirmed-badge');
const confidenceScoreText = document.getElementById('confidence-score');
const confidenceBar = document.getElementById('confidence-bar');
const latencyValText = document.getElementById('latency-val');
const modelValText = document.getElementById('model-val');
const reloadBtn = document.getElementById('reload-btn');
const historyList = document.getElementById('history-list');
const clearHistoryBtn = document.getElementById('clear-history-btn');
const toast = document.getElementById('toast');

// --- ROUTING LOGIC ---
function switchView(viewElement) {
    viewHome.classList.remove('active');
    viewAuth.classList.remove('active');
    viewDashboard.classList.remove('active');
    
    viewHome.style.display = 'none';
    viewAuth.style.display = 'none';
    viewDashboard.style.display = 'none';
    
    viewElement.style.display = 'flex';
    // Small delay to allow display:flex to apply before opacity transition
    setTimeout(() => {
        viewElement.classList.add('active');
        updateHeader();
        if (viewElement === viewDashboard) {
            renderHistory();
        }
    }, 10);
}

function updateHeader() {
    if (currentUser) {
        headerActionLink.textContent = 'Sign Out';
        headerGetStarted.style.display = 'inline-flex';
        headerGetStarted.innerHTML = 'Dashboard <i class="fa-solid fa-gauge" style="margin-left:5px"></i>';
    } else {
        headerActionLink.textContent = 'Sign In';
        headerGetStarted.style.display = 'inline-flex';
        headerGetStarted.innerHTML = 'Get Started <i class="fa-solid fa-arrow-right" style="margin-left:5px"></i>';
    }
}

// Initial state check
function initApp() {
    // Clear old string-based sessions to prevent errors with new object-based DB
    const savedUser = localStorage.getItem('emoai_active_user');
    if (savedUser && savedUser.includes('@')) {
        localStorage.removeItem('emoai_active_user');
    } else if (savedUser) {
        currentUser = savedUser;
    }
    
    // Always start on home as requested
    switchView(viewHome);
    
    // Automatically load the user's custom Google AI model
    loadTeachableMachineModel(MY_TEACHABLE_MACHINE_URL);
}

// Navigation Events
headerActionLink.addEventListener('click', (e) => {
    e.preventDefault();
    if (headerActionLink.textContent === 'Sign Out') {
        localStorage.removeItem('emoai_active_user');
        currentUser = null;
        switchView(viewHome);
        showToast('Session Terminated.');
    } else if (headerActionLink.textContent === 'Dashboard') {
        switchView(viewDashboard);
    } else {
        switchView(viewAuth);
    }
});

logoLink.addEventListener('click', () => {
    switchView(viewHome);
});

btnGetStarted.addEventListener('click', () => {
    if (currentUser) {
        switchView(viewDashboard);
    } else {
        switchView(viewAuth);
    }
});

headerGetStarted.addEventListener('click', () => {
    if (currentUser) {
        switchView(viewDashboard);
    } else {
        switchView(viewAuth);
    }
});

// --- AUTHENTICATION ---
let isSignUpMode = false;

tabLogin.addEventListener('click', () => {
    isSignUpMode = false;
    tabLogin.classList.add('active');
    tabSignup.classList.remove('active');
    nameGroup.style.display = 'none';
    authTitle.textContent = 'Welcome Back';
    authSubmitBtn.innerHTML = 'Sign In <i class="fa-solid fa-arrow-right"></i>';
    authError.style.display = 'none';
});

tabSignup.addEventListener('click', () => {
    isSignUpMode = true;
    tabSignup.classList.add('active');
    tabLogin.classList.remove('active');
    nameGroup.style.display = 'block';
    authTitle.textContent = 'Create Account';
    authSubmitBtn.innerHTML = 'Sign Up <i class="fa-solid fa-arrow-right"></i>';
    authError.style.display = 'none';
});

const passwordInput = document.getElementById('password');
const togglePasswordBtn = document.getElementById('toggle-password');
const togglePasswordIcon = document.getElementById('toggle-password-icon');

togglePasswordBtn.addEventListener('click', () => {
    const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
    passwordInput.setAttribute('type', type);
    togglePasswordIcon.className = type === 'password' ? 'fa-solid fa-eye' : 'fa-solid fa-eye-slash';
});

authForm.addEventListener('submit', (e) => {
    e.preventDefault();
    authError.style.display = 'none';
    const email = emailInput.value.trim();
    const password = passwordInput.value;
    const name = nameInput.value.trim();
    
    if (!email || !password) return;

    // Fetch or initialize DB
    let users = JSON.parse(localStorage.getItem(DB_USERS));
    // If it's an array (old schema), convert to object
    if (Array.isArray(users)) {
        users = {};
        localStorage.setItem(DB_USERS, JSON.stringify(users));
    }

    if (isSignUpMode) {
        // Sign Up Logic
        if (users[email]) {
            authError.textContent = 'Account already exists! Please switch to LOGIN.';
            authError.style.display = 'block';
            return;
        }
        if (!name) {
            authError.textContent = 'Please enter your full name.';
            authError.style.display = 'block';
            return;
        }
        
        // Save new user
        users[email] = { name: name, password: password };
        localStorage.setItem(DB_USERS, JSON.stringify(users));
        
        const displayName = name;
        localStorage.setItem('emoai_active_user', displayName);
        currentUser = displayName;
        switchView(viewDashboard);
        showToast(`Account created successfully. Welcome, ${displayName}!`);
        
    } else {
        // Login Logic
        if (!users[email]) {
            authError.textContent = 'Account not found. Please SIGN UP first.';
            authError.style.display = 'block';
            return;
        }
        if (users[email].password !== password) {
            authError.textContent = 'Incorrect password. Please try again.';
            authError.style.display = 'block';
            return;
        }
        
        const displayName = users[email].name || email.split('@')[0];
        localStorage.setItem('emoai_active_user', displayName);
        currentUser = displayName;
        switchView(viewDashboard);
        showToast(`Welcome back, ${displayName}!`);
    }
});

// --- TEACHABLE MACHINE LOGIC ---
async function loadTeachableMachineModel(urlValue) {
    try {
        modelValText.textContent = 'CONNECTING...';
        showToast('Loading Custom Neural Weights...');
        
        const URL = urlValue.endsWith('/') ? urlValue : urlValue + '/';
        const modelURL = URL + 'model.json';
        const metadataURL = URL + 'metadata.json';

        model = await tmImage.load(modelURL, metadataURL);
        maxPredictions = model.getTotalClasses();
        isModelLoaded = true;
        
        modelValText.textContent = 'Custom Google Model (Active)';
        showToast('Your Custom AI is Ready.');
    } catch (e) {
        console.error(e);
        modelValText.textContent = 'LOAD ERROR';
        showToast('Failed to load your model.');
    }
}

// Upload Logic
uploadArea.addEventListener('click', () => {
    imageUploadInput.click();
});

// Prevent bubbling when clicking clear
clearImageBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    resetPreview();
});

reloadBtn.addEventListener('click', () => {
    resetPreview();
    showToast('Dashboard Reset.');
});

clearHistoryBtn.addEventListener('click', () => {
    if (confirm('Are you sure you want to clear all history?')) {
        localStorage.setItem(DB_LOGS, JSON.stringify({}));
        renderHistory();
        showToast('History Cleared.');
    }
});

imageUploadInput.addEventListener('change', (e) => {
    if (e.target.files && e.target.files[0]) {
        const reader = new FileReader();
        
        reader.onload = function(event) {
            imagePreview.src = event.target.result;
            uploadContent.style.display = 'none';
            previewContainer.style.display = 'flex';
            
            // Wait for image to load before predicting
            imagePreview.onload = () => {
                analyzeImage();
            }
        }
        
        reader.readAsDataURL(e.target.files[0]);
    }
});

function resetPreview() {
    imageUploadInput.value = '';
    imagePreview.src = '';
    previewContainer.style.display = 'none';
    uploadContent.style.display = 'block';
    
    // Reset Results
    primaryClassText.textContent = 'PENDING';
    primaryClassText.style.color = 'var(--primary)';
    confirmedBadge.style.visibility = 'hidden';
    confidenceScoreText.textContent = '0.0%';
    confidenceBar.style.width = '0%';
    latencyValText.textContent = '--ms';
}

async function analyzeImage() {
    if (!isModelLoaded) return;

    primaryClassText.textContent = 'ANALYZING...';
    primaryClassText.style.color = 'var(--text-gray)';
    confirmedBadge.style.visibility = 'hidden';
    
    const startTime = performance.now();

    try {
        // Predict using the user's custom Teachable Machine model
        const prediction = await model.predict(imagePreview);
        
        // Find the class with the highest probability
        let topPred = prediction[0];
        for (let i = 1; i < maxPredictions; i++) {
            if (prediction[i].probability > topPred.probability) {
                topPred = prediction[i];
            }
        }

        const endTime = performance.now();
        const latency = Math.round(endTime - startTime);
        const probPercentage = (topPred.probability * 100).toFixed(1);
        const topClassName = topPred.className.toUpperCase();
        
        // Update UI
        primaryClassText.textContent = topClassName;
        primaryClassText.style.color = 'var(--primary)';
        confirmedBadge.style.visibility = 'visible';
        
        confidenceScoreText.textContent = `${probPercentage}%`;
        confidenceBar.style.width = `${probPercentage}%`;
        latencyValText.textContent = `${latency}ms`;

        // SAVE TO HISTORY
        saveToHistory(topClassName, probPercentage);

    } catch (e) {
        console.error("Prediction error:", e);
        showToast("Error analyzing image with your model.");
    }
}

// --- HISTORY LOGIC ---
function saveToHistory(emotion, confidence) {
    let logs = JSON.parse(localStorage.getItem(DB_LOGS));
    // If it's an array (old schema), convert to object
    if (Array.isArray(logs)) logs = {};
    
    const timestamp = new Date().toLocaleString();
    const logId = Date.now();
    
    // Store in global logs
    logs[logId] = {
        emotion: emotion,
        confidence: confidence,
        time: timestamp,
        user: currentUser || 'Guest'
    };
    
    localStorage.setItem(DB_LOGS, JSON.stringify(logs));
    renderHistory();
}

function renderHistory() {
    let logs = JSON.parse(localStorage.getItem(DB_LOGS));
    if (Array.isArray(logs)) logs = {};
    
    historyList.innerHTML = '';
    
    const entries = Object.entries(logs).sort((a, b) => b[0] - a[0]); // Sort by newest
    
    if (entries.length === 0) {
        historyList.innerHTML = '<div class="no-history">No previous records found.</div>';
        return;
    }

    entries.forEach(([id, log]) => {
        const item = document.createElement('div');
        item.className = 'history-item';
        item.innerHTML = `
            <div class="history-info">
                <span class="history-emotion">${log.emotion}</span>
                <span class="history-date">${log.time}</span>
            </div>
            <div class="history-confidence">
                ${log.confidence}% Confidence
            </div>
        `;
        historyList.appendChild(item);
    });
}

// --- UTILS ---
let toastTimeout;
function showToast(msg) {
    toast.textContent = msg;
    toast.classList.add('show');
    clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

// Bootstrap
initApp();
