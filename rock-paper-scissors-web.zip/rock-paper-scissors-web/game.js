// ===== Rock-Paper-Scissors AI Game Engine =====

(function () {
    'use strict';

    // --- Constants ---
    const MOVES = ['R', 'P', 'S'];
    const COUNTERS = { R: 'P', P: 'S', S: 'R' };
    const FULL_NAMES = { R: 'Rock', P: 'Paper', S: 'Scissors' };
    const EMOJIS = { R: '✊', P: '✋', S: '✌️' };
    const THINKING_DELAY = 700; // ms

    // --- State ---
    let history = {
        R: { R: 0, P: 0, S: 0 },
        P: { R: 0, P: 0, S: 0 },
        S: { R: 0, P: 0, S: 0 },
    };
    let lastUserMove = null;
    let scoreUser = 0;
    let scoreAi = 0;
    let round = 0;
    let isProcessing = false;
    
    // Leaderboard Stats (Load from localStorage)
    let currentStreak = 0;
    let highStreak = parseInt(localStorage.getItem('neonBrawlHighStreak')) || 0;
    let totalWins = parseInt(localStorage.getItem('neonBrawlTotalWins')) || 0;

    // --- DOM Elements ---
    const $gameContainer = document.querySelector('.game-container');

    const $scorePlayer = document.getElementById('score-player');
    const $scoreAi = document.getElementById('score-ai');
    const $roundBadge = document.getElementById('round-badge');
    const $playerEmoji = document.getElementById('player-emoji');
    const $aiEmoji = document.getElementById('ai-emoji');
    const $clashText = document.getElementById('clash-text');
    const $historyList = document.getElementById('history-list');
    const $historyEmpty = document.getElementById('history-empty');
    const $btnReset = document.getElementById('btn-reset');
    const $moveBtns = document.querySelectorAll('.move-btn');

    const $navRules = document.getElementById('nav-rules');
    const $navLeaderboard = document.getElementById('nav-leaderboard');
    const $rulesModal = document.getElementById('rules-modal');
    const $leaderboardModal = document.getElementById('leaderboard-modal');
    const $closeModals = document.querySelectorAll('.close-modal');
    const $statHighStreak = document.getElementById('stat-high-streak');
    const $statCurrentStreak = document.getElementById('stat-current-streak');
    const $statTotalWins = document.getElementById('stat-total-wins');


    // --- Modals Logic ---
    $navRules.addEventListener('click', (e) => {
        e.preventDefault();
        $rulesModal.classList.remove('hidden');
    });

    $navLeaderboard.addEventListener('click', (e) => {
        e.preventDefault();
        $statHighStreak.textContent = highStreak;
        $statCurrentStreak.textContent = currentStreak;
        $statTotalWins.textContent = totalWins;
        $leaderboardModal.classList.remove('hidden');
    });

    $closeModals.forEach(btn => {
        btn.addEventListener('click', () => {
            $rulesModal.classList.add('hidden');
            $leaderboardModal.classList.add('hidden');
        });
    });

    // --- AI Logic (pattern-learning) ---
    function aiChoose() {
        if (lastUserMove === null) {
            return MOVES[Math.floor(Math.random() * 3)];
        }

        const patterns = history[lastUserMove];
        const predicted = Object.keys(patterns).reduce((a, b) =>
            patterns[a] >= patterns[b] ? a : b
        );

        if (patterns[predicted] === 0) {
            return MOVES[Math.floor(Math.random() * 3)];
        }

        // Add a 30% chance to play randomly so the AI doesn't win every time
        if (Math.random() < 0.3) {
            return MOVES[Math.floor(Math.random() * 3)];
        }

        return COUNTERS[predicted]; // Counter the predicted move
    }

    function determineResult(user, ai) {
        if (user === ai) return 'tie';
        if (COUNTERS[ai] === user) return 'win';
        return 'lose';
    }

    // --- History List ---
    function addHistoryItem(roundNum, userMove, aiMove, result) {
        if ($historyEmpty) $historyEmpty.remove();

        const item = document.createElement('div');
        item.className = 'history-item';

        const resultLabel = result === 'win' ? 'WIN' : result === 'lose' ? 'LOSS' : 'TIE';

        item.innerHTML = `
            <span class="history-round">#${roundNum}</span>
            <span class="history-moves">${EMOJIS[userMove]} ${FULL_NAMES[userMove]}  vs  ${EMOJIS[aiMove]} ${FULL_NAMES[aiMove]}</span>
            <span class="history-result ${result}">${resultLabel}</span>
        `;

        $historyList.prepend(item);
    }

    // --- Animations ---
    function animateScorePop(el) {
        el.classList.remove('pop');
        void el.offsetWidth; // Trigger reflow
        el.classList.add('pop');
    }

    function setArenaResult(playerResult) {
        // Clear previous classes
        $playerEmoji.classList.remove('win', 'lose', 'tie');
        $aiEmoji.classList.remove('win', 'lose', 'tie');
        $clashText.classList.remove('result-win', 'result-lose', 'result-tie');
        
        $gameContainer.classList.remove('shake-hard');
        void $gameContainer.offsetWidth; // Trigger reflow

        if (playerResult === 'win') {
            $playerEmoji.classList.add('win');
            $aiEmoji.classList.add('lose');
            $clashText.classList.add('result-win');
            $clashText.textContent = 'You Win! 🎉';
        } else if (playerResult === 'lose') {
            $playerEmoji.classList.add('lose');
            $aiEmoji.classList.add('win');
            $clashText.classList.add('result-lose');
            $clashText.textContent = 'AI Wins! 💀';
            $gameContainer.classList.add('shake-hard');
        } else {
            $playerEmoji.classList.add('tie');
            $aiEmoji.classList.add('tie');
            $clashText.classList.add('result-tie');
            $clashText.textContent = "It's a Tie! 🤝";
        }
    }

    function revealEmoji(el) {
        el.classList.remove('reveal');
        void el.offsetWidth;
        el.classList.add('reveal');
    }

    function createRipple(btn, e) {
        const ripple = document.createElement('span');
        ripple.className = 'ripple';
        const rect = btn.getBoundingClientRect();
        const size = Math.max(rect.width, rect.height);
        ripple.style.width = ripple.style.height = size + 'px';
        ripple.style.left = (e.clientX - rect.left - size / 2) + 'px';
        ripple.style.top = (e.clientY - rect.top - size / 2) + 'px';
        btn.appendChild(ripple);
        setTimeout(() => ripple.remove(), 500);
    }

    // --- Core Game Flow ---
    function playRound(userMove, clickEvent) {
        if (isProcessing) return;
        isProcessing = true;
        round++;

        // Disable buttons
        $moveBtns.forEach(btn => btn.classList.add('disabled'));

        // Show player move immediately
        $playerEmoji.textContent = EMOJIS[userMove];
        revealEmoji($playerEmoji);

        // Reset arena styles
        $playerEmoji.classList.remove('win', 'lose', 'tie');
        $aiEmoji.classList.remove('win', 'lose', 'tie');
        $clashText.classList.remove('result-win', 'result-lose', 'result-tie');
        $clashText.textContent = 'AI is thinking…';

        // AI "thinking" animation
        $aiEmoji.textContent = '🤔';
        $aiEmoji.classList.add('shaking');

        setTimeout(() => {
            const aiMove = aiChoose();

            // Reveal AI move
            $aiEmoji.classList.remove('shaking');
            $aiEmoji.textContent = EMOJIS[aiMove];
            revealEmoji($aiEmoji);

            // Determine result
            const result = determineResult(userMove, aiMove);

            if (result === 'win') {
                scoreUser++;
                totalWins++;
                currentStreak++;
                if (currentStreak > highStreak) {
                    highStreak = currentStreak;
                    localStorage.setItem('neonBrawlHighStreak', highStreak);
                }
                localStorage.setItem('neonBrawlTotalWins', totalWins);
                
                $scorePlayer.textContent = scoreUser;
                animateScorePop($scorePlayer);
            } else if (result === 'lose') {
                scoreAi++;
                currentStreak = 0;
                $scoreAi.textContent = scoreAi;
                animateScorePop($scoreAi);
            } else {
                currentStreak = 0;
            }

            setArenaResult(result);
            $roundBadge.textContent = `Round ${round}`;

            // Update AI history
            if (lastUserMove !== null) {
                history[lastUserMove][userMove]++;
            }
            lastUserMove = userMove;

            addHistoryItem(round, userMove, aiMove, result);

            // Re-enable buttons
            $moveBtns.forEach(btn => btn.classList.remove('disabled'));
            isProcessing = false;
        }, THINKING_DELAY);
    }

    // --- Reset ---
    function resetGame() {
        history = {
            R: { R: 0, P: 0, S: 0 },
            P: { R: 0, P: 0, S: 0 },
            S: { R: 0, P: 0, S: 0 },
        };
        lastUserMove = null;
        scoreUser = 0;
        scoreAi = 0;
        round = 0;
        isProcessing = false;

        $scorePlayer.textContent = '0';
        $scoreAi.textContent = '0';
        $roundBadge.textContent = 'Round 1';
        $playerEmoji.textContent = '❓';
        $aiEmoji.textContent = '🤖';
        $clashText.textContent = 'Choose your weapon!';

        $playerEmoji.classList.remove('win', 'lose', 'tie', 'reveal');
        $aiEmoji.classList.remove('win', 'lose', 'tie', 'reveal', 'shaking');
        $clashText.classList.remove('result-win', 'result-lose', 'result-tie');

        $historyList.innerHTML = '<p class="history-empty" id="history-empty">No rounds played yet.</p>';

        $moveBtns.forEach(btn => btn.classList.remove('disabled'));
    }

    // --- Event Listeners ---
    $moveBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            createRipple(btn, e);
            const move = btn.dataset.move;
            playRound(move, e);
        });
    });

    $btnReset.addEventListener('click', resetGame);

    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => {
        const key = e.key.toUpperCase();
        if (key === 'R') document.getElementById('btn-rock').click();
        else if (key === 'P') document.getElementById('btn-paper').click();
        else if (key === 'S') document.getElementById('btn-scissors').click();
    });

})();
